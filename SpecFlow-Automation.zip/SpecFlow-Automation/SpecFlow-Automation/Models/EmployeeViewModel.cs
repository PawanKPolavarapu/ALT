﻿namespace SpecFlow_Automation.Models
{
    public static class EmployeeViewModel
    {
        public static List<Employee> ListOfEmployees;
        public static List<Employee> GetEmployees()
        {
            ListOfEmployees = new List<Employee>();


            ListOfEmployees.Add(new Employee { Id = 1, Age = 26, Salary = 10000, Gender = 'M', Name = "Mohan" });
            ListOfEmployees.Add(new Employee { Id = 2, Age = 35, Salary = 30000, Gender = 'F', Name = "Marry" });
            ListOfEmployees.Add(new Employee { Id = 3, Age = 45, Salary = 45000, Gender = 'M', Name = "John" });
            ListOfEmployees.Add(new Employee { Id = 4, Age = 58, Salary = 10600, Gender = 'F', Name = "Priya" });
            return ListOfEmployees;
        }

     

    }
}
