﻿namespace SpecFlow_Automation.Models
{
    public class Gender
    {
        public char value { get; set; }
        public string Name { get; set; }
    }
}
