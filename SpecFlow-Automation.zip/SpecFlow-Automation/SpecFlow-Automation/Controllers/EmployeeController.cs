﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SpecFlow_Automation.Models;

namespace SpecFlow_Automation.Controllers
{
    
    public class EmployeeController : Controller
    {
      
        public static List<Employee> ListOfEmployees = new List<Employee>()
        {
        new Employee { Id = 1, Age = 26, Salary = 10000, Gender = "Male", Name = "Mohan" },
        new Employee { Id = 2, Age = 35, Salary = 30000, Gender = "Female", Name = "Marry" },
        new Employee { Id = 3, Age = 45, Salary = 45000, Gender = "Male", Name = "John" },
        new Employee { Id = 4, Age = 46, Salary = 10600, Gender = "Female", Name = "Priya" },
        new Employee { Id = 5, Age = 41, Salary = 10600, Gender = "Male", Name = "Pawan" },

        };
        static List<Gender> genderList = new List<Gender> {
                                             new Gender{ Name="Male",   value = 'M'},
                                             new Gender{ Name="Female", value = 'F'}
                                             };


        public EmployeeController() {

           
        }
        // GET: EmployeeController
        public ActionResult Index()
        {

           
            return View(ListOfEmployees);

        }

        // GET: EmployeeController/Details/5
        public ActionResult Details(int id)
        {
            Employee model = ListOfEmployees.Where(e=>e.Id==id).First();
            return View(model);
        }

        // GET: EmployeeController/Create
        public ActionResult Create()
        {
            
            return View();
        }

        // POST: EmployeeController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View("Create", model);
                }
                ListOfEmployees.Add(model);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Edit/5
        public ActionResult Edit(int id)
        {
            Employee model = ListOfEmployees.Where(e => e.Id == id).First();

            return View(model);
          
        }

        // POST: EmployeeController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Employee model)
        {
           Employee obj= ListOfEmployees.Where(e=>e.Id==model.Id).First();
            obj.Salary=model.Salary;
            obj.Age=model.Age;
            obj.Name=model.Name;
            obj.Gender=model.Gender;

            return RedirectToAction("Index");
        }

        // GET: EmployeeController/Delete/5
        public ActionResult Delete(int id)
        {
            Employee model = ListOfEmployees.Where(e => e.Id == id).First();
           

            return View(model);
        }

        // POST: EmployeeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Employee model)
        {
            Employee model1 = ListOfEmployees.Where(e => e.Id == id).First();
            ListOfEmployees.Remove(model1);
            return RedirectToAction("Index");
            //try
            //{
            //    return RedirectToAction(nameof(Index));
            //}
            //catch
            //{
            //    return View();
            //}
        }
    }
}
