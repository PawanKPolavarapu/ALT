using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Text;
//using SpecFlow_Automation.Models;

namespace TestAuto.Specs.StepDefinitions
{
    [Binding]
    public sealed class CreateEmployeeStepDefinitions
    {
        private IWebDriver driver;

        public CreateEmployeeStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
        }

        [Given(@"User opens the browser")]
        public void GivenUserOpensTheBrowser()
        {
            //driver = new ChromeDriver();
            //driver.Manage().Window.Maximize();
        }

        [Given(@"user launches the create page of Employee")]
        public void GivenUserLaunchesTheCreatePageOfEmployee()
        {
            driver.Url = "https://localhost:7221/Employee/Create";
            Thread.Sleep(5000);
        }



        // scnario context
        // scnario outline
        [When(@"User enters the data in all the mandatory fields")]
        public void WhenUserEntersTheDataInAllTheMandatoryFields()
        {
            driver.FindElement(By.Name("Id")).SendKeys("8");
            driver.FindElement(By.Name("Name")).SendKeys("Test spec flow user1");
            driver.FindElement(By.Name("Age")).SendKeys("25");
            SelectElement dropDown = new SelectElement(driver.FindElement(By.Name("Gender")));
            dropDown.SelectByValue("M");
            driver.FindElement(By.Name("Salary")).SendKeys("99999");
            driver.FindElement(By.Name("Active")).Click();
            Thread.Sleep(5000);
        }

        [When(@"user clicks on Create button")]
        public void WhenUserClicksOnCreateButton()
        {
            driver.FindElement(By.Name("btnCreate")).Click();
            Thread.Sleep(4000);
        }

        [Then(@"user will be navigated to listing page with newly added row")]
        public void ThenUserWillBeNavigatedToListingPageWithNewlyAddedRow()
        {

            driver.Navigate().GoToUrl("https://localhost:7221/Employee");
            Thread.Sleep(5000);

            // xpath of html table
            var elemTable = driver.FindElement(By.XPath("//div[@id='divbody']//table[1]"));

            // Fetch all Row of the table
            List<IWebElement> lstTrElem = new List<IWebElement>(elemTable.FindElements(By.TagName("tr")));
            StringBuilder strRowData = new StringBuilder();

            // Traverse each row
            foreach (var elemTr in lstTrElem)
            {
                // Fetch the columns from a particuler row
                List<IWebElement> lstTdElem = new List<IWebElement>(elemTr.FindElements(By.TagName("td")));
                if (lstTdElem.Count > 0)
                {
                    // Traverse each column
                    foreach (var elemTd in lstTdElem)
                    {
                        // "\t\t" is used for Tab Space between two Text
                        strRowData.Append(elemTd.Text + "\t\t");
                                             
                    }
                }
               
            }
            Thread.Sleep(4000);
            //Assert.Contains("Test spec flow user1", strRowData.ToString());
            //Assert.Contains("99999", strRowData.ToString());
        }

    }
}