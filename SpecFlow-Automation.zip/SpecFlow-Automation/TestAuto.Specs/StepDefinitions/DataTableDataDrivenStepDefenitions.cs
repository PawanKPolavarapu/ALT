using Microsoft.AspNetCore.Mvc.RazorPages;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SpecFlow_Automation.Models;
using System.Xml.Linq;
using System;
using TechTalk.SpecFlow.Assist;

//using SpecFlow_Automation.Models;

namespace TestAuto.Specs.StepDefinitions
{
    [Binding]
    public sealed class DataTableDataDrivenStepDefenitions
    {
        private IWebDriver driver;

        public DataTableDataDrivenStepDefenitions(IWebDriver driver)
        {
            this.driver = driver;
        }
               


        [When(@"User enters all the mandatory fields")]
        public void WhenUserEntersAllTheMandatoryFields(Table table)
        {
            var employeeTestData = table.CreateSet<EmployeeTestData>();

            foreach (var emp in employeeTestData)
            {
                driver.FindElement(By.Name("Id")).Clear();
                driver.FindElement(By.Name("Id")).SendKeys(emp.id);
                driver.FindElement(By.Name("Name")).Clear();
                driver.FindElement(By.Name("Name")).SendKeys(emp.name);
                driver.FindElement(By.Name("Age")).Clear();
                driver.FindElement(By.Name("Age")).SendKeys(emp.age);
            SelectElement dropDown = new SelectElement(driver.FindElement(By.Name("Gender")));
             
            dropDown.SelectByValue(emp.gender);
                driver.FindElement(By.Name("Salary")).Clear();
                driver.FindElement(By.Name("Salary")).SendKeys(emp.salary);
            if (emp.active != null)
            {
                driver.FindElement(By.Name("Active")).Click();
            }
                Thread.Sleep(2000);
            }

        }




    }
    public class EmployeeTestData
    {
        public string id { get; set; }
        public string name { get; set; }
        public string age { get; set; }
        public string salary { get; set; }
        public string gender { get; set; }
        public string active { get; set; }
    }

}