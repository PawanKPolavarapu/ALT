using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

//using SpecFlow_Automation.Models;

namespace TestAuto.Specs.StepDefinitions
{
    [Binding]
    public sealed class ExamplesDataDrivenStepDefenitions
    {
        private IWebDriver driver;

        public ExamplesDataDrivenStepDefenitions(IWebDriver driver)
        {
            this.driver = driver;
        }

      
        [When(@"User enters all the mandatory fields '([^']*)' '([^']*)' '([^']*)' '([^']*)' '([^']*)' '([^']*)'")]
        public void WhenUserEntersAllTheMandatoryFields(string id, string name, string age, string gender, string salary, string active)
        {
            driver.FindElement(By.Name("Id")).SendKeys(id);
            driver.FindElement(By.Name("Name")).SendKeys(name);
            driver.FindElement(By.Name("Age")).SendKeys(age);
            SelectElement dropDown = new SelectElement(driver.FindElement(By.Name("Gender")));
            dropDown.SelectByValue(gender);
            driver.FindElement(By.Name("Salary")).SendKeys(salary);
            if (active != null)
            {
                driver.FindElement(By.Name("Active")).Click();
            }

            Thread.Sleep(5000);
        }


    }
}