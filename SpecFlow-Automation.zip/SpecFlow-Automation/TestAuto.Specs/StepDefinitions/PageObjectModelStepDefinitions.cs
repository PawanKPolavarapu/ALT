using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TestAuto.Specs.Pages;

//using SpecFlow_Automation.Models;

namespace TestAuto.Specs.StepDefinitions
{
    [Binding]
    public sealed class PageObjectModelStepDefinitions
    {
        private IWebDriver driver;
        EmployeeListing employeeListing;
        CreateEmployee createEmployee;
      
        public PageObjectModelStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
        }


        [Given(@"Enter the Employee listing page")]
        public void GivenEnterTheEmployeeListingPage()
        {
            driver.Url = "https://localhost:7221/";
            Thread.Sleep(4000);
        }

        [When(@"Click on Create Employee link")]
        public void WhenClickOnCreateEmployeeLink()
        {
            employeeListing = new EmployeeListing(driver);
            createEmployee = employeeListing.clickOnCreateEmployeeLink();
            Thread.Sleep(4000);
        }

        [When(@"Enter all the mandatory fields")]
        public void WhenEnterAllTheMandatoryFields()
        {
            createEmployee = new CreateEmployee(driver);
            createEmployee.EnterAllMandatoryValues("20","Test page object model user 1","30","M","123456","True");
            Thread.Sleep(3000);
        }

        [When(@"Click on Create button")]
        public void WhenClickOnCreateButton()
        {
            //createEmployee = new CreateEmployee(driver);
            employeeListing = createEmployee.ClickOnCreateButton();
        }

        [Then(@"User will be navigated to Employee listing page along with new data")]
        public void ThenUserWillBeNavigatedToEmployeeListingPageAlongWithNewData()
        {
          string data=  employeeListing.ValidateData();


            Assert.Contains("Test page object model user 1", data);
            Assert.Contains("123456", data);

        }


    }
}