using Microsoft.AspNetCore.Mvc.RazorPages;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using SpecFlow_Automation.Models;
using System.Xml.Linq;
using System;
//using SpecFlow_Automation.Models;

namespace TestAuto.Specs.StepDefinitions
{
    [Binding]
    public sealed class DataDrivenTestingStepStepDefenitions
    {
        private IWebDriver driver;

        public DataDrivenTestingStepStepDefenitions(IWebDriver driver)
        {
            this.driver = driver;
        }



        [When(@"User enters id as '([^']*)' name as '([^']*)' age as '([^']*)' gender as '([^']*)'salary as '([^']*)'active as '([^']*)'")]
        public void WhenUserEntersIdAsNameAsAgeAsGenderAsSalaryAsActiveAs(string id, string name, string age, string gender, string salary, string active)
        {
            driver.FindElement(By.Name("Id")).SendKeys(id);
            driver.FindElement(By.Name("Name")).SendKeys(name);
            driver.FindElement(By.Name("Age")).SendKeys(age);
            SelectElement dropDown = new SelectElement(driver.FindElement(By.Name("Gender")));
            dropDown.SelectByValue(gender);
            driver.FindElement(By.Name("Salary")).SendKeys(salary);
            if (active != null)
            {
                driver.FindElement(By.Name("Active")).Click();
            }

            Thread.Sleep(5000);
        }





    }
}