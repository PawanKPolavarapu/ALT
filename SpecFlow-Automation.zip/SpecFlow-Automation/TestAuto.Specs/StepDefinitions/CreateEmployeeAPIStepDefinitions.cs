using Newtonsoft.Json;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using RestSharp;
using SpecFlow_Automation.Models;
using System.Net;
using System.Text;
using static MongoDB.Bson.Serialization.Serializers.SerializerHelper;
//using SpecFlow_Automation.Models;

namespace TestAuto.Specs.StepDefinitions
{
    [Binding]
    public sealed class CreateEmployeeAPIStepDefinitions
    {
        private IWebDriver driver;
        private RestClient restClient;
        private RestRequest request;
        private RestResponse response;
        

        public CreateEmployeeAPIStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
        }

        [Given(@"User calls '([^']*)'")]
        public void GivenUserCalls(string url)
        {
            restClient = new RestClient(url);

        }

        [Given(@"User enters id as '([^']*)' name as '([^']*)' age as '([^']*)' gender as '([^']*)'salary as '([^']*)'active as '([^']*)'")]
        public void GivenUserEntersIdAsNameAsAgeAsGenderAsSalaryAsActiveAs(string id, string name, string age, string gender, string salary, string isActive)
        {
            request = new RestRequest("",Method.Post);
                        request.AddHeader("Content-Type", "application/json");

            Employee empObj = new Employee();
            empObj.Active = bool.Parse(isActive);
            empObj.Name = name;
            empObj.Age = Int32.Parse(age);
            empObj.Id = Int32.Parse(id);
            empObj.Salary = Convert.ToDecimal(salary);
            empObj.Gender = Convert.ToChar(gender);
            string json = JsonConvert.SerializeObject(empObj);
          
            request.AddStringBody(json, DataFormat.Json);

        }

        [When(@"User send the request with Post method")]
        public void WhenUserSendTheRequestWithPostMethod()
        {
            response = restClient.Execute(request);
        }

        [Then(@"new record should be added")]
        public void ThenNewRecordShouldBeAdded()
        {
        
            Assert.Equal(200, (int)response.StatusCode);
            
            Employee? result = JsonConvert.DeserializeObject<Employee>(response.Content);
            Assert.Equal("API Post method test user", result.Name);

        }


    }
}