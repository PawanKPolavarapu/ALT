﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAuto.Specs.Pages
{
    public class EmployeeListing
    {
             
            private IWebDriver driver;

            public EmployeeListing(IWebDriver driver)
            {
                this.driver = driver;
            }

            By createEmployeeLink = By.Id("lnkCreate");
        By _htmltable = By.XPath("//div[@id='divbody']//table[1]");

        public CreateEmployee clickOnCreateEmployeeLink()
        {
            driver.FindElement(createEmployeeLink).Click();
            return new CreateEmployee(driver);
        }

        public string ValidateData()
        {
            // xpath of html table
            var elemTable = driver.FindElement(_htmltable);

            // Fetch all Row of the table
            List<IWebElement> lstTrElem = new List<IWebElement>(elemTable.FindElements(By.TagName("tr")));
            StringBuilder strRowData = new StringBuilder();

            // Traverse each row
            foreach (var elemTr in lstTrElem)
            {
                // Fetch the columns from a particuler row
                List<IWebElement> lstTdElem = new List<IWebElement>(elemTr.FindElements(By.TagName("td")));
                if (lstTdElem.Count > 0)
                {
                    // Traverse each column
                    foreach (var elemTd in lstTdElem)
                    {
                        // "\t\t" is used for Tab Space between two Text
                        strRowData.Append(elemTd.Text + "\t\t");

                    }
                }

            }
           return strRowData.ToString();

        }



    }
}
