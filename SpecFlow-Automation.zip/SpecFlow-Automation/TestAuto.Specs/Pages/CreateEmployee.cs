﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAuto.Specs.Pages
{
    public class CreateEmployee
    {
        private IWebDriver driver;

        public CreateEmployee(IWebDriver driver)
        {
            this.driver = driver;
        }
        By _id = By.Name("Id");
        By _name = By.Name("Name");
        By _age = By.Name("Age");
        By _gender = By.Name("Gender");
        By _salary = By.Name("Salary");
        By _active = By.Name("Active");
        By _btnCreate = By.Id("btnCreate");
        public void EnterAllMandatoryValues(string id,string name,string age, string gender,string salary, string active)
        {
            driver.FindElement(_id).SendKeys(id);
            driver.FindElement(_name).SendKeys(name);
            driver.FindElement(_age).SendKeys(age);
            SelectElement dropDown = new SelectElement(driver.FindElement(_gender));
            dropDown.SelectByValue(gender);
            driver.FindElement(_salary).SendKeys(salary);

            if (active != null)
            {
                driver.FindElement(_active).Click();
            }

                     

            //return new EmployeeListing(driver);
        }

        public EmployeeListing ClickOnCreateButton()
        {
            driver.FindElement(_btnCreate).Click();
            return new EmployeeListing(driver);
        }






    }
}
