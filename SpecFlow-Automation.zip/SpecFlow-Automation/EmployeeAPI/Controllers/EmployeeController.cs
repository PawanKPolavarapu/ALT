﻿using EmployeeAPI.Model;
using EmployeeAPI.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        // GET: api/<EmployeeController>
       

        public static List<Employee> ListOfEmployees = new List<Employee>()
        {
        new Employee { Id = 1, Age = 26, Salary = 10000, Gender = 'M', Name = "Mohan" , Active =true},
        new Employee { Id = 2, Age = 35, Salary = 30000, Gender ='F', Name = "Marry" , Active =false},
        new Employee { Id = 3, Age = 45, Salary = 45000, Gender = 'M', Name = "John" , Active =true},
        new Employee { Id = 4, Age = 46, Salary = 10600, Gender = 'F', Name = "Priya", Active = true},
        new Employee { Id = 5, Age = 41, Salary = 10600, Gender = 'M', Name = "Pawan" , Active =false},

        };
        static List<Gender> genderList = new List<Gender> {
                                   new Gender {Name="--Select a gender--", value =' '},
                                             new Gender{ Name="Male",   value = 'M'},
                                             new Gender{ Name="Female", value = 'F'}

                                             };

      [HttpGet]

        public List<Employee> Get()
        {
            return  EmployeeViewModel.ListOfEmployees;
        }

        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        public Employee Get(int id)
        {
           Employee objEmp = EmployeeViewModel.ListOfEmployees.Where(e=>e.Id== id).FirstOrDefault();
            return objEmp;
        }

        // POST api/<EmployeeController>
        [HttpPost]
        public Employee Post(Employee emp)
        {
            EmployeeViewModel.AddEmployee(emp);
            return (emp);
        }

        //// PUT api/<EmployeeController>/5
       [HttpPut]
        public Employee Put(Employee emp)
        {
            EmployeeViewModel.UpdateEmployee(emp);
            return (emp);
        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            EmployeeViewModel.DeleteEmployee(id);
        }
    }
}
