﻿using EmployeeAPI.Models;

namespace EmployeeAPI.Model
{
    public static class EmployeeViewModel
    {


        public static List<Employee> ListOfEmployees = new List<Employee>()
        {
        new Employee { Id = 1, Age = 26, Salary = 10000, Gender = 'M', Name = "Mohan" , Active =true},
        new Employee { Id = 2, Age = 35, Salary = 30000, Gender ='F', Name = "Marry" , Active =false},
        new Employee { Id = 3, Age = 45, Salary = 45000, Gender = 'M', Name = "John" , Active =true},
        new Employee { Id = 4, Age = 46, Salary = 10600, Gender = 'F', Name = "Priya", Active = true},
        new Employee { Id = 5, Age = 41, Salary = 10600, Gender = 'M', Name = "Pawan" , Active =false},

        };
        static List<Gender> genderList = new List<Gender> {
                                   new Gender {Name="--Select a gender--", value =' '},
                                             new Gender{ Name="Male",   value = 'M'},
                                             new Gender{ Name="Female", value = 'F'}

                                             };



        public static void AddEmployee(Employee emp)
        {
            ListOfEmployees.Add(emp);

        }
        public static void DeleteEmployee(int id)
        {
            Employee empObject = ListOfEmployees.Where(e => e.Id == id).FirstOrDefault();
            ListOfEmployees.Remove(empObject);

        }
        public static void UpdateEmployee(Employee emp)
        {
            Employee empObject = ListOfEmployees.Where(e=>e.Id == emp.Id).FirstOrDefault();
            empObject.Name= emp.Name;
            empObject.Gender = emp.Gender;
            empObject.Age = emp.Age;
            empObject.Salary = emp.Salary;
            empObject.Active = emp.Active;
        }

    }
}
