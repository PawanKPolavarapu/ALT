﻿namespace EmployeeAPI.Models
{
    public class Gender
    {
        public char value { get; set; }
        public string Name { get; set; }
    }
}
