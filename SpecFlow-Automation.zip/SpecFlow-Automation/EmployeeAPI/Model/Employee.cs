﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;

namespace EmployeeAPI.Models
{
    public class Employee
    {
        [Required]
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required ]
        [Range(18, 56, ErrorMessage = "Age Must be between 18 to 56")]
        public int Age { get; set; }
        [Required]
        public char Gender { get; set; }
        [Required]
        public decimal Salary { get; set; }
       
        public bool Active { get; set; }


    }


}
